const prisma = require("../config/prisma");
const asyncHandler = require("../utils/asyncHandler");

const findOwnedNotification = (notification_id, user_id) =>
  prisma.notifications.findFirst({
    where: { notification_id: Number(notification_id), user_id }
  });

// GET /api/notifications?unread=true
exports.getNotifications = asyncHandler(async (req, res) => {
  const { unread } = req.query;

  const notifications = await prisma.notifications.findMany({
    where: {
      user_id: req.user.user_id,
      ...(unread === "true" ? { is_read: false } : {})
    },
    orderBy: { created_at: "desc" }
  });

  res.status(200).json({ notifications });
});

// PUT /api/notifications/:id/read
exports.markAsRead = asyncHandler(async (req, res) => {
  const existing = await findOwnedNotification(req.params.id, req.user.user_id);

  if (!existing) {
    return res.status(404).json({ message: "Notification not found" });
  }

  const notification = await prisma.notifications.update({
    where: { notification_id: existing.notification_id },
    data: { is_read: true }
  });

  res.status(200).json({ message: "Notification marked as read", notification });
});

// PUT /api/notifications/read-all
exports.markAllAsRead = asyncHandler(async (req, res) => {
  await prisma.notifications.updateMany({
    where: { user_id: req.user.user_id, is_read: false },
    data: { is_read: true }
  });

  res.status(200).json({ message: "All notifications marked as read" });
});

// DELETE /api/notifications/:id
exports.deleteNotification = asyncHandler(async (req, res) => {
  const existing = await findOwnedNotification(req.params.id, req.user.user_id);

  if (!existing) {
    return res.status(404).json({ message: "Notification not found" });
  }

  await prisma.notifications.delete({ where: { notification_id: existing.notification_id } });

  res.status(200).json({ message: "Notification deleted" });
});
