const prisma = require("../config/prisma");
const asyncHandler = require("../utils/asyncHandler");

const VALID_PERIODS = ["weekly", "monthly", "yearly"];

const findOwnedBudget = (budget_id, user_id) =>
  prisma.budgets.findFirst({ where: { budget_id: Number(budget_id), user_id } });

// POST /api/budgets
exports.createBudget = asyncHandler(async (req, res) => {
  const { category_id, budget_amount, period_type, start_date, alert_threshold } = req.body;

  if (!category_id || budget_amount === undefined || !period_type || !start_date) {
    return res.status(400).json({
      message: "category_id, budget_amount, period_type and start_date are required"
    });
  }

  if (!VALID_PERIODS.includes(period_type)) {
    return res.status(400).json({ message: `period_type must be one of: ${VALID_PERIODS.join(", ")}` });
  }

  const category = await prisma.categories.findFirst({
    where: { category_id: Number(category_id), user_id: req.user.user_id }
  });

  if (!category) {
    return res.status(404).json({ message: "Category not found" });
  }

  const budget = await prisma.budgets.create({
    data: {
      user_id: req.user.user_id,
      category_id: Number(category_id),
      budget_amount,
      period_type,
      start_date: new Date(start_date),
      alert_threshold
    }
  });

  res.status(201).json({ message: "Budget created", budget });
});

// GET /api/budgets
exports.getBudgets = asyncHandler(async (req, res) => {
  const budgets = await prisma.budgets.findMany({
    where: { user_id: req.user.user_id },
    include: { categories: true },
    orderBy: { start_date: "desc" }
  });

  res.status(200).json({ budgets });
});

// GET /api/budgets/:id
exports.getBudgetById = asyncHandler(async (req, res) => {
  const budget = await findOwnedBudget(req.params.id, req.user.user_id);

  if (!budget) {
    return res.status(404).json({ message: "Budget not found" });
  }

  res.status(200).json({ budget });
});

// GET /api/budgets/:id/progress - amount spent vs budget for the current period
exports.getBudgetProgress = asyncHandler(async (req, res) => {
  const budget = await findOwnedBudget(req.params.id, req.user.user_id);

  if (!budget) {
    return res.status(404).json({ message: "Budget not found" });
  }

  const spend = await prisma.transactions.aggregate({
    where: {
      category_id: budget.category_id,
      transaction_type: "debit",
      transaction_date: { gte: new Date(budget.start_date) },
      accounts: { user_id: req.user.user_id }
    },
    _sum: { amount: true }
  });

  const spent = Number(spend._sum.amount || 0);
  const budgetAmount = Number(budget.budget_amount);

  res.status(200).json({
    budget_id: budget.budget_id,
    budget_amount: budgetAmount,
    spent,
    remaining: budgetAmount - spent,
    percent_used: budgetAmount > 0 ? Number(((spent / budgetAmount) * 100).toFixed(2)) : 0
  });
});

// PUT /api/budgets/:id
exports.updateBudget = asyncHandler(async (req, res) => {
  const existing = await findOwnedBudget(req.params.id, req.user.user_id);

  if (!existing) {
    return res.status(404).json({ message: "Budget not found" });
  }

  const { category_id, budget_amount, period_type, start_date, alert_threshold } = req.body;

  if (period_type && !VALID_PERIODS.includes(period_type)) {
    return res.status(400).json({ message: `period_type must be one of: ${VALID_PERIODS.join(", ")}` });
  }

  if (category_id) {
    const category = await prisma.categories.findFirst({
      where: { category_id: Number(category_id), user_id: req.user.user_id }
    });
    if (!category) {
      return res.status(404).json({ message: "Category not found" });
    }
  }

  const budget = await prisma.budgets.update({
    where: { budget_id: existing.budget_id },
    data: {
      ...(category_id !== undefined ? { category_id: Number(category_id) } : {}),
      ...(budget_amount !== undefined ? { budget_amount } : {}),
      ...(period_type !== undefined ? { period_type } : {}),
      ...(start_date !== undefined ? { start_date: new Date(start_date) } : {}),
      ...(alert_threshold !== undefined ? { alert_threshold } : {})
    }
  });

  res.status(200).json({ message: "Budget updated", budget });
});

// DELETE /api/budgets/:id
exports.deleteBudget = asyncHandler(async (req, res) => {
  const existing = await findOwnedBudget(req.params.id, req.user.user_id);

  if (!existing) {
    return res.status(404).json({ message: "Budget not found" });
  }

  await prisma.budgets.delete({ where: { budget_id: existing.budget_id } });

  res.status(200).json({ message: "Budget deleted" });
});
