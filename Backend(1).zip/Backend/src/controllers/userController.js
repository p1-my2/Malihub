const bcrypt = require("bcrypt");
const prisma = require("../config/prisma");
const asyncHandler = require("../utils/asyncHandler");

const sanitizeUser = (user) => {
  const { password_hash, ...safeUser } = user;
  return safeUser;
};

// GET /api/users/me
exports.getProfile = asyncHandler(async (req, res) => {
  const user = await prisma.users.findUnique({
    where: { user_id: req.user.user_id }
  });

  if (!user) {
    return res.status(404).json({ message: "User not found" });
  }

  res.status(200).json({ user: sanitizeUser(user) });
});

// PUT /api/users/me
exports.updateProfile = asyncHandler(async (req, res) => {
  const { first_name, last_name, phone_number, currency_preference } = req.body;

  const user = await prisma.users.update({
    where: { user_id: req.user.user_id },
    data: {
      ...(first_name !== undefined ? { first_name } : {}),
      ...(last_name !== undefined ? { last_name } : {}),
      ...(phone_number !== undefined ? { phone_number } : {}),
      ...(currency_preference !== undefined ? { currency_preference } : {}),
      updated_at: new Date()
    }
  });

  res.status(200).json({ message: "Profile updated", user: sanitizeUser(user) });
});

// PUT /api/users/me/password
exports.changePassword = asyncHandler(async (req, res) => {
  const { current_password, new_password } = req.body;

  if (!current_password || !new_password) {
    return res.status(400).json({
      message: "current_password and new_password are required"
    });
  }

  const user = await prisma.users.findUnique({
    where: { user_id: req.user.user_id }
  });

  const isMatch = await bcrypt.compare(current_password, user.password_hash);

  if (!isMatch) {
    return res.status(401).json({ message: "Current password is incorrect" });
  }

  const hashedPassword = await bcrypt.hash(new_password, 10);

  await prisma.users.update({
    where: { user_id: req.user.user_id },
    data: { password_hash: hashedPassword, updated_at: new Date() }
  });

  res.status(200).json({ message: "Password updated successfully" });
});

// DELETE /api/users/me
exports.deactivateAccount = asyncHandler(async (req, res) => {
  await prisma.users.update({
    where: { user_id: req.user.user_id },
    data: { is_active: false, updated_at: new Date() }
  });

  res.status(200).json({ message: "Account deactivated" });
});
