const prisma = require("../config/prisma");
const asyncHandler = require("../utils/asyncHandler");

const VALID_TYPES = ["checking", "savings", "credit_card", "cash"];

// helper: fetch an account only if it belongs to the requesting user
const findOwnedAccount = (account_id, user_id) =>
  prisma.accounts.findFirst({ where: { account_id: Number(account_id), user_id } });

// POST /api/accounts
exports.createAccount = asyncHandler(async (req, res) => {
  const { account_name, account_type, balance } = req.body;

  if (!account_name || !account_type) {
    return res.status(400).json({ message: "account_name and account_type are required" });
  }

  if (!VALID_TYPES.includes(account_type)) {
    return res.status(400).json({
      message: `account_type must be one of: ${VALID_TYPES.join(", ")}`
    });
  }

  const account = await prisma.accounts.create({
    data: {
      user_id: req.user.user_id,
      account_name,
      account_type,
      balance: balance !== undefined ? balance : 0
    }
  });

  res.status(201).json({ message: "Account created", account });
});

// GET /api/accounts
exports.getAccounts = asyncHandler(async (req, res) => {
  const accounts = await prisma.accounts.findMany({
    where: { user_id: req.user.user_id },
    orderBy: { created_at: "desc" }
  });

  res.status(200).json({ accounts });
});

// GET /api/accounts/:id
exports.getAccountById = asyncHandler(async (req, res) => {
  const account = await findOwnedAccount(req.params.id, req.user.user_id);

  if (!account) {
    return res.status(404).json({ message: "Account not found" });
  }

  res.status(200).json({ account });
});

// PUT /api/accounts/:id
exports.updateAccount = asyncHandler(async (req, res) => {
  const existing = await findOwnedAccount(req.params.id, req.user.user_id);

  if (!existing) {
    return res.status(404).json({ message: "Account not found" });
  }

  const { account_name, account_type, balance, is_active } = req.body;

  if (account_type && !VALID_TYPES.includes(account_type)) {
    return res.status(400).json({
      message: `account_type must be one of: ${VALID_TYPES.join(", ")}`
    });
  }

  const account = await prisma.accounts.update({
    where: { account_id: existing.account_id },
    data: {
      ...(account_name !== undefined ? { account_name } : {}),
      ...(account_type !== undefined ? { account_type } : {}),
      ...(balance !== undefined ? { balance } : {}),
      ...(is_active !== undefined ? { is_active } : {})
    }
  });

  res.status(200).json({ message: "Account updated", account });
});

// DELETE /api/accounts/:id
exports.deleteAccount = asyncHandler(async (req, res) => {
  const existing = await findOwnedAccount(req.params.id, req.user.user_id);

  if (!existing) {
    return res.status(404).json({ message: "Account not found" });
  }

  await prisma.accounts.delete({ where: { account_id: existing.account_id } });

  res.status(200).json({ message: "Account deleted" });
});
