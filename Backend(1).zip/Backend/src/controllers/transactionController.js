const prisma = require("../config/prisma");
const asyncHandler = require("../utils/asyncHandler");
const notify = require("../utils/notify");

const VALID_TYPES = ["debit", "credit"];

const balanceDelta = (transaction_type, amount) =>
  transaction_type === "credit" ? amount : -amount;

const findOwnedTransaction = async (transaction_id, user_id) =>
  prisma.transactions.findFirst({
    where: {
      transaction_id: Number(transaction_id),
      accounts: { user_id }
    },
    include: { accounts: true, categories: true }
  });

// Checks the budget for this category/period and fires a notification
// if the user has gone over their alert threshold.
const checkBudgetAlert = async (user_id, category_id) => {
  const budget = await prisma.budgets.findFirst({
    where: { user_id, category_id }
  });

  if (!budget) return;

  const periodStart = new Date(budget.start_date);
  const spend = await prisma.transactions.aggregate({
    where: {
      category_id,
      transaction_type: "debit",
      transaction_date: { gte: periodStart },
      accounts: { user_id }
    },
    _sum: { amount: true }
  });

  const totalSpent = Number(spend._sum.amount || 0);
  const budgetAmount = Number(budget.budget_amount);

  if (totalSpent > budgetAmount) {
    await notify(
      user_id,
      "budget_exceeded",
      `You've exceeded your budget of ${budgetAmount} for this category (spent ${totalSpent.toFixed(2)}).`
    );
  }
};

// POST /api/transactions
exports.createTransaction = asyncHandler(async (req, res) => {
  const { account_id, category_id, amount, transaction_type, description, transaction_date } = req.body;

  if (!account_id || !category_id || amount === undefined || !transaction_type) {
    return res.status(400).json({
      message: "account_id, category_id, amount and transaction_type are required"
    });
  }

  if (!VALID_TYPES.includes(transaction_type)) {
    return res.status(400).json({ message: `transaction_type must be one of: ${VALID_TYPES.join(", ")}` });
  }

  if (Number(amount) <= 0) {
    return res.status(400).json({ message: "amount must be greater than 0" });
  }

  const account = await prisma.accounts.findFirst({
    where: { account_id: Number(account_id), user_id: req.user.user_id }
  });

  if (!account) {
    return res.status(404).json({ message: "Account not found" });
  }

  const category = await prisma.categories.findFirst({
    where: { category_id: Number(category_id), user_id: req.user.user_id }
  });

  if (!category) {
    return res.status(404).json({ message: "Category not found" });
  }

  const [transaction] = await prisma.$transaction([
    prisma.transactions.create({
      data: {
        account_id: Number(account_id),
        category_id: Number(category_id),
        amount,
        transaction_type,
        description,
        ...(transaction_date ? { transaction_date: new Date(transaction_date) } : {})
      }
    }),
    prisma.accounts.update({
      where: { account_id: Number(account_id) },
      data: { balance: { increment: balanceDelta(transaction_type, Number(amount)) } }
    })
  ]);

  if (transaction_type === "debit") {
    await checkBudgetAlert(req.user.user_id, Number(category_id));
  }

  res.status(201).json({ message: "Transaction created", transaction });
});

// GET /api/transactions?account_id=&category_id=&type=&from=&to=
exports.getTransactions = asyncHandler(async (req, res) => {
  const { account_id, category_id, type, from, to } = req.query;

  const transactions = await prisma.transactions.findMany({
    where: {
      accounts: { user_id: req.user.user_id },
      ...(account_id ? { account_id: Number(account_id) } : {}),
      ...(category_id ? { category_id: Number(category_id) } : {}),
      ...(type ? { transaction_type: type } : {}),
      ...(from || to
        ? {
            transaction_date: {
              ...(from ? { gte: new Date(from) } : {}),
              ...(to ? { lte: new Date(to) } : {})
            }
          }
        : {})
    },
    include: { categories: true, accounts: true },
    orderBy: { transaction_date: "desc" }
  });

  res.status(200).json({ transactions });
});

// GET /api/transactions/:id
exports.getTransactionById = asyncHandler(async (req, res) => {
  const transaction = await findOwnedTransaction(req.params.id, req.user.user_id);

  if (!transaction) {
    return res.status(404).json({ message: "Transaction not found" });
  }

  res.status(200).json({ transaction });
});

// PUT /api/transactions/:id
exports.updateTransaction = asyncHandler(async (req, res) => {
  const existing = await findOwnedTransaction(req.params.id, req.user.user_id);

  if (!existing) {
    return res.status(404).json({ message: "Transaction not found" });
  }

  const { category_id, amount, transaction_type, description, transaction_date } = req.body;

  if (transaction_type && !VALID_TYPES.includes(transaction_type)) {
    return res.status(400).json({ message: `transaction_type must be one of: ${VALID_TYPES.join(", ")}` });
  }

  const newAmount = amount !== undefined ? Number(amount) : Number(existing.amount);
  const newType = transaction_type || existing.transaction_type;

  // Reverse the old effect on the balance, then apply the new one.
  const reverseDelta = -balanceDelta(existing.transaction_type, Number(existing.amount));
  const applyDelta = balanceDelta(newType, newAmount);
  const netDelta = reverseDelta + applyDelta;

  if (category_id) {
    const category = await prisma.categories.findFirst({
      where: { category_id: Number(category_id), user_id: req.user.user_id }
    });
    if (!category) {
      return res.status(404).json({ message: "Category not found" });
    }
  }

  const [transaction] = await prisma.$transaction([
    prisma.transactions.update({
      where: { transaction_id: existing.transaction_id },
      data: {
        ...(category_id !== undefined ? { category_id: Number(category_id) } : {}),
        ...(amount !== undefined ? { amount: newAmount } : {}),
        ...(transaction_type !== undefined ? { transaction_type: newType } : {}),
        ...(description !== undefined ? { description } : {}),
        ...(transaction_date !== undefined ? { transaction_date: new Date(transaction_date) } : {})
      }
    }),
    prisma.accounts.update({
      where: { account_id: existing.account_id },
      data: { balance: { increment: netDelta } }
    })
  ]);

  res.status(200).json({ message: "Transaction updated", transaction });
});

// DELETE /api/transactions/:id
exports.deleteTransaction = asyncHandler(async (req, res) => {
  const existing = await findOwnedTransaction(req.params.id, req.user.user_id);

  if (!existing) {
    return res.status(404).json({ message: "Transaction not found" });
  }

  const reverseDelta = -balanceDelta(existing.transaction_type, Number(existing.amount));

  await prisma.$transaction([
    prisma.transactions.delete({ where: { transaction_id: existing.transaction_id } }),
    prisma.accounts.update({
      where: { account_id: existing.account_id },
      data: { balance: { increment: reverseDelta } }
    })
  ]);

  res.status(200).json({ message: "Transaction deleted" });
});
