const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const prisma = require("../config/prisma");
const asyncHandler = require("../utils/asyncHandler");

const DEFAULT_CATEGORIES = [
  { category_name: "Food & Dining", icon: "utensils" },
  { category_name: "Transport", icon: "car" },
  { category_name: "Shopping", icon: "shopping-bag" },
  { category_name: "Bills & Utilities", icon: "file-text" },
  { category_name: "Entertainment", icon: "film" },
  { category_name: "Salary", icon: "banknote" },
  { category_name: "Other", icon: "circle" }
];

const signToken = (user_id) =>
  jwt.sign({ user_id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || "7d"
  });

const sanitizeUser = (user) => {
  const { password_hash, ...safeUser } = user;
  return safeUser;
};

// POST /api/auth/register
exports.register = asyncHandler(async (req, res) => {
  const { first_name, last_name, email, phone_number, password, currency_preference } = req.body;

  if (!first_name || !last_name || !email || !password) {
    return res.status(400).json({
      message: "first_name, last_name, email and password are required"
    });
  }

  const existingUser = await prisma.users.findUnique({ where: { email } });

  if (existingUser) {
    return res.status(409).json({ message: "Email already exists" });
  }

  const hashedPassword = await bcrypt.hash(password, 10);

  const user = await prisma.users.create({
    data: {
      first_name,
      last_name,
      email,
      phone_number,
      password_hash: hashedPassword,
      ...(currency_preference ? { currency_preference } : {})
    }
  });

  // Seed default categories so a new user has something to assign
  // transactions/budgets to right away.
  await prisma.categories.createMany({
    data: DEFAULT_CATEGORIES.map((c) => ({
      user_id: user.user_id,
      category_name: c.category_name,
      icon: c.icon,
      is_default: true
    }))
  });

  const token = signToken(user.user_id);

  res.status(201).json({
    message: "User registered successfully",
    token,
    user: sanitizeUser(user)
  });
});

// POST /api/auth/login
exports.login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: "email and password are required" });
  }

  const user = await prisma.users.findUnique({ where: { email } });

  if (!user || !user.is_active) {
    return res.status(401).json({ message: "Invalid credentials" });
  }

  const isMatch = await bcrypt.compare(password, user.password_hash);

  if (!isMatch) {
    return res.status(401).json({ message: "Invalid credentials" });
  }

  await prisma.users.update({
    where: { user_id: user.user_id },
    data: { last_login_at: new Date() }
  });

  const token = signToken(user.user_id);

  res.status(200).json({
    message: "Login successful",
    token,
    user: sanitizeUser(user)
  });
});
