const prisma = require("../config/prisma");
const asyncHandler = require("../utils/asyncHandler");
const notify = require("../utils/notify");

const findOwnedGoal = (goal_id, user_id) =>
  prisma.financial_goals.findFirst({ where: { goal_id: Number(goal_id), user_id } });

// POST /api/goals
exports.createGoal = asyncHandler(async (req, res) => {
  const { goal_name, target_amount, current_amount, deadline } = req.body;

  if (!goal_name || target_amount === undefined) {
    return res.status(400).json({ message: "goal_name and target_amount are required" });
  }

  const goal = await prisma.financial_goals.create({
    data: {
      user_id: req.user.user_id,
      goal_name,
      target_amount,
      current_amount: current_amount !== undefined ? current_amount : 0,
      ...(deadline ? { deadline: new Date(deadline) } : {})
    }
  });

  res.status(201).json({ message: "Goal created", goal });
});

// GET /api/goals
exports.getGoals = asyncHandler(async (req, res) => {
  const goals = await prisma.financial_goals.findMany({
    where: { user_id: req.user.user_id },
    orderBy: { deadline: "asc" }
  });

  res.status(200).json({ goals });
});

// GET /api/goals/:id
exports.getGoalById = asyncHandler(async (req, res) => {
  const goal = await findOwnedGoal(req.params.id, req.user.user_id);

  if (!goal) {
    return res.status(404).json({ message: "Goal not found" });
  }

  res.status(200).json({ goal });
});

// PUT /api/goals/:id
exports.updateGoal = asyncHandler(async (req, res) => {
  const existing = await findOwnedGoal(req.params.id, req.user.user_id);

  if (!existing) {
    return res.status(404).json({ message: "Goal not found" });
  }

  const { goal_name, target_amount, current_amount, deadline } = req.body;

  const goal = await prisma.financial_goals.update({
    where: { goal_id: existing.goal_id },
    data: {
      ...(goal_name !== undefined ? { goal_name } : {}),
      ...(target_amount !== undefined ? { target_amount } : {}),
      ...(current_amount !== undefined ? { current_amount } : {}),
      ...(deadline !== undefined ? { deadline: new Date(deadline) } : {})
    }
  });

  res.status(200).json({ message: "Goal updated", goal });
});

// POST /api/goals/:id/contribute - add funds towards a goal
exports.contributeToGoal = asyncHandler(async (req, res) => {
  const { amount } = req.body;

  if (amount === undefined || Number(amount) <= 0) {
    return res.status(400).json({ message: "amount must be greater than 0" });
  }

  const existing = await findOwnedGoal(req.params.id, req.user.user_id);

  if (!existing) {
    return res.status(404).json({ message: "Goal not found" });
  }

  const previousAmount = Number(existing.current_amount);
  const target = Number(existing.target_amount);
  const newAmount = previousAmount + Number(amount);

  const goal = await prisma.financial_goals.update({
    where: { goal_id: existing.goal_id },
    data: { current_amount: newAmount }
  });

  const wasComplete = previousAmount >= target;
  const isNowComplete = newAmount >= target;

  if (isNowComplete && !wasComplete) {
    await notify(
      req.user.user_id,
      "goal_milestone",
      `Congratulations! You've reached your goal "${existing.goal_name}".`
    );
  } else {
    const prevPercent = target > 0 ? Math.floor((previousAmount / target) * 100 / 25) : 0;
    const newPercent = target > 0 ? Math.floor((newAmount / target) * 100 / 25) : 0;
    if (newPercent > prevPercent) {
      await notify(
        req.user.user_id,
        "goal_milestone",
        `You're ${Math.min(newPercent * 25, 100)}% of the way to your goal "${existing.goal_name}".`
      );
    }
  }

  res.status(200).json({ message: "Contribution added", goal });
});

// DELETE /api/goals/:id
exports.deleteGoal = asyncHandler(async (req, res) => {
  const existing = await findOwnedGoal(req.params.id, req.user.user_id);

  if (!existing) {
    return res.status(404).json({ message: "Goal not found" });
  }

  await prisma.financial_goals.delete({ where: { goal_id: existing.goal_id } });

  res.status(200).json({ message: "Goal deleted" });
});
