const prisma = require("../config/prisma");
const asyncHandler = require("../utils/asyncHandler");

const findOwnedCategory = (category_id, user_id) =>
  prisma.categories.findFirst({ where: { category_id: Number(category_id), user_id } });

// POST /api/categories
exports.createCategory = asyncHandler(async (req, res) => {
  const { category_name, icon } = req.body;

  if (!category_name) {
    return res.status(400).json({ message: "category_name is required" });
  }

  const existing = await prisma.categories.findFirst({
    where: { user_id: req.user.user_id, category_name }
  });

  if (existing) {
    return res.status(409).json({ message: "Category already exists" });
  }

  const category = await prisma.categories.create({
    data: { user_id: req.user.user_id, category_name, icon }
  });

  res.status(201).json({ message: "Category created", category });
});

// GET /api/categories
exports.getCategories = asyncHandler(async (req, res) => {
  const categories = await prisma.categories.findMany({
    where: { user_id: req.user.user_id },
    orderBy: { category_name: "asc" }
  });

  res.status(200).json({ categories });
});

// GET /api/categories/:id
exports.getCategoryById = asyncHandler(async (req, res) => {
  const category = await findOwnedCategory(req.params.id, req.user.user_id);

  if (!category) {
    return res.status(404).json({ message: "Category not found" });
  }

  res.status(200).json({ category });
});

// PUT /api/categories/:id
exports.updateCategory = asyncHandler(async (req, res) => {
  const existing = await findOwnedCategory(req.params.id, req.user.user_id);

  if (!existing) {
    return res.status(404).json({ message: "Category not found" });
  }

  const { category_name, icon } = req.body;

  const category = await prisma.categories.update({
    where: { category_id: existing.category_id },
    data: {
      ...(category_name !== undefined ? { category_name } : {}),
      ...(icon !== undefined ? { icon } : {})
    }
  });

  res.status(200).json({ message: "Category updated", category });
});

// DELETE /api/categories/:id
exports.deleteCategory = asyncHandler(async (req, res) => {
  const existing = await findOwnedCategory(req.params.id, req.user.user_id);

  if (!existing) {
    return res.status(404).json({ message: "Category not found" });
  }

  if (existing.is_default) {
    return res.status(400).json({ message: "Default categories cannot be deleted" });
  }

  await prisma.categories.delete({ where: { category_id: existing.category_id } });

  res.status(200).json({ message: "Category deleted" });
});
