const prisma = require("../config/prisma");

const notify = (user_id, notification_type, message) =>
  prisma.notifications.create({
    data: { user_id, notification_type, message }
  });

module.exports = notify;
