const express = require("express");
const cors = require("cors");

const authRoutes = require("./routes/authRoute");
const userRoutes = require("./routes/userRoute");
const accountRoutes = require("./routes/accountRoute");
const categoryRoutes = require("./routes/categoryRoute");
const budgetRoutes = require("./routes/budgetRoute");
const goalRoutes = require("./routes/goalRoute");
const transactionRoutes = require("./routes/transactionRoute");
const notificationRoutes = require("./routes/notificationRoute");

const app = express();

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
  res.send("Malihub Backend is running");
});

app.use("/api/auth", authRoutes);
app.use("/api/users", userRoutes);
app.use("/api/accounts", accountRoutes);
app.use("/api/categories", categoryRoutes);
app.use("/api/budgets", budgetRoutes);
app.use("/api/goals", goalRoutes);
app.use("/api/transactions", transactionRoutes);
app.use("/api/notifications", notificationRoutes);

// 404 handler
app.use((req, res) => {
  res.status(404).json({ message: "Route not found" });
});

// Central error handler (catches errors forwarded by asyncHandler,
// including Prisma errors)
app.use((err, req, res, next) => {
  console.error(err);

  if (err.code === "P2025") {
    return res.status(404).json({ message: "Resource not found" });
  }

  if (err.code === "P2002") {
    return res.status(409).json({ message: "A record with these details already exists" });
  }

  res.status(500).json({ message: "Server error" });
});

module.exports = app;
