const express = require("express");
const router = express.Router();

const budgetController = require("../controllers/budgetController");
const authMiddleware = require("../middleware/authMiddleware");

router.use(authMiddleware);

router.post("/", budgetController.createBudget);
router.get("/", budgetController.getBudgets);
router.get("/:id", budgetController.getBudgetById);
router.get("/:id/progress", budgetController.getBudgetProgress);
router.put("/:id", budgetController.updateBudget);
router.delete("/:id", budgetController.deleteBudget);

module.exports = router;
